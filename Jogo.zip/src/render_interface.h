#pragma once
#include "engine_lib.h"
#include "assets.h"
#include "input.h"
#define vec2 Vec2
#define ivec2 IVec2
#define vec4 Vec4
//#define BIT(i) 1 << i

//constants
constexpr int MAX_TRANSFORMS = 1000;

int RENDER_OPTION_FLIP_X = BIT(0);
int RENDER_OPTION_FLIP_Y = BIT(1);

//structs
struct OrthographicCamera2D
{
    float zoom = 1.0f;
    Vec2 dimensions;
    Vec2 pos;
};

struct DrawData
{
    int animIdx;
    int render;
};

struct Transform
{
    Vec2 pos;
    Vec2 size;
    IVec2 atlasOffset;
    IVec2 spriteSize;
    int animIdx;
    int render;
};

struct RenderData
{
    OrthographicCamera2D gameCamera;
    OrthographicCamera2D uiCamera;

    int transformCount;
    Transform transforms[MAX_TRANSFORMS];
};

//render
static RenderData* renderData;

//utility
IVec2 screen_to_world(IVec2 screenPos)
{
    OrthographicCamera2D camera = renderData->gameCamera;

    int xPos = (float)screenPos.x / 
               (float)input->screenSize.x *
               camera.dimensions.x;

    xPos += -camera.dimensions.x / 2.0f + camera.pos.x;

    int yPos = (float)screenPos.y /
               (float)input->screenSize.y *
               camera.dimensions.y;

    yPos += -camera.dimensions.y / 2.0f - camera.pos.y;

    return {xPos, yPos};
}

int animate(float* time, int frameCount, float duration = 1.0f)
{
    while(*time > duration)
    {
        *time -= duration;
    }

    int animIdx = (int)((*time / duration) * frameCount);

    if(animIdx >= frameCount)
    {
        animIdx = frameCount - 1;
    } 

    return animIdx;
}


//funcs

void draw_quad(Vec2 pos, Vec2 size)
{
    Transform transform = {};
    transform.pos = pos - size /2.0f;
    transform.size = size;
    transform.atlasOffset = {6, 204};
    transform.spriteSize = {16, 16};

    renderData->transforms[renderData->transformCount++] = transform;
}

void draw_spike(Vec2 pos, Vec2 size)
{
    Transform transform = {};
    transform.pos = pos - size /2.0f;
    transform.size = size;
    transform.atlasOffset = {0, 164};
    transform.spriteSize = {18, 11};

    renderData->transforms[renderData->transformCount++] = transform;
}

void draw_sprite(SpriteID spriteID, Vec2 pos, DrawData drawData = {})
{
    Sprite sprite = get_sprite(spriteID);

    sprite.atlasOffset.x += drawData.animIdx * sprite.spriteSize.x;

    Transform transform = {};
    transform.pos = pos - vec_2(sprite.spriteSize) / 2.0f;
    transform.size = vec_2(sprite.spriteSize);
    transform.atlasOffset = sprite.atlasOffset;
    transform.spriteSize = sprite.spriteSize;
    transform.render = drawData.render;

    renderData->transforms[renderData->transformCount++] = transform;
}

void draw_sprite(SpriteID spriteID, IVec2 pos, DrawData drawData = {})
{
    draw_sprite(spriteID, vec_2(pos), drawData);
}