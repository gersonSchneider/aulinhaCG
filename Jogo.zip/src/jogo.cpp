#include "jogo.h"
#include "input.h"
#include "engine_lib.h"
#include "assets.h"
#include "render_interface.h"

// Funcs
IVec2 get_grid_pos(IVec2 worldPos)
{
    return {worldPos.x / TILESIZE, worldPos.y / TILESIZE};
}

Tile* get_tile(int x, int y)
{
    Tile* tile = nullptr;

    if (x >= 0 && x < WORLD_GRID.x && y >= 0 && y < WORLD_GRID.y)
    {
        tile = &gameState->worldGrid[x][y];
    }

    return tile;
}

Tile* get_tile(IVec2 worldPos)
{
    IVec2 gridPos = get_grid_pos(worldPos);
    return get_tile(gridPos.x, gridPos.y);

    int x = worldPos.x / TILESIZE;
    int y = worldPos.y / TILESIZE;

    return get_tile(x, y);
}

IRect get_player_rect()
{
    return {
        gameState->player.pos.x - 4,
        gameState->player.pos.y - 19,
        12,
        36
    };
}

IVec2 get_tile_pos(int x, int y)
{
    return {x * TILESIZE, y * TILESIZE};
}

IRect get_tile_rect(int x, int y)
{
    return {get_tile_pos(x, y), 8, 8};
}

int check_last_pressed()
{
  if(key_is_down(KEY_RIGHT))
  {
    gameState->lastPressed = 1;
  }

  else if (key_is_down(KEY_LEFT))
  {
    gameState->lastPressed = 0;
  }
  
  return gameState->lastPressed;
}

void handle_collision(Player& player, Tile* tile)
{
    if(tile->isDangerous)
    {
        player.pos = {0, 0};
    }
}



void check_collide(Player& player)
{
    IRect playerRect = get_player_rect();
    IVec2 playerGridPos = get_grid_pos(player.pos);
    
    const int range = 1;

    for(int x = playerGridPos.x - range; x <= playerGridPos.x + range; x++)
    {
        for(int y = playerGridPos.y - range; x <= playerGridPos.y + range; y++)
        {
            Tile * tile = get_tile(x, y);
            if(tile && tile->isVisible)
            {
                IRect tileRect = get_tile_rect(x, y);
                
                if(rect_collision(playerRect, tileRect))
                {
                    handle_collision(player, tile);
                }
            }
        }
    }
}

void simulate()
{
    float dt = UPDATE_DELAY;

    Player& player = gameState->player;
    player.prevPos = player.pos;

    static Vec2 remainder = {};
    static bool grounded = false;
    constexpr float runSpeed = 2.0f;
    constexpr float runAcceleration = 10.0f;
    constexpr float runReduce = 22.0f;
    constexpr float flyReduce = 12.0f;
    constexpr float gravity = 13.0f;
    constexpr float fallSpeed = 3.6f;
    constexpr float jumpSpeed = -4.0f;




    {
        // respawn provisorio
        int last = check_last_pressed();


        if(key_is_down(KEY_R))
        {
            player.pos = {};
        }

        if(!grounded && last == 1)
        {
            player.animation = PLAYER_ANIM_PULO;
        }

        if(!grounded && last == 0)
        {
            player.animation = PLAYER_ANIM_PULO_LEFT;
        }

        if (key_is_down(KEY_LEFT))
        {
            if(grounded)
            {
                player.animation = PLAYER_ANIM_RUN_LEFT;
            }

            float mult = 1.0f;
            if (player.speed.x > 0.0f)
            {
                mult = 3.0f;
            }
            player.runAnimTime += dt;
            player.speed.x = approach(player.speed.x, -runSpeed, runAcceleration * mult * dt);
        }

        if (key_is_down(KEY_RIGHT))
        {
            if(grounded)
            {
                player.animation = PLAYER_ANIM_RUN;
            }

            float mult = 1.0f;
            if (player.speed.x < 0.0f)
            {
                mult = 3.0f;
            }
            player.runAnimTime += dt;
            player.speed.x = approach(player.speed.x, runSpeed, runAcceleration * mult * dt);
        }

        if (key_pressed_once(KEY_UP) && grounded)
        {
            player.speed.y = jumpSpeed;
            grounded = false;
        }
        
        if(grounded && !key_is_down(KEY_LEFT) && !key_is_down(KEY_RIGHT) && last == 1)
        {
            player.animation = PLAYER_ANIM_IDLE;
            player.runAnimTime += dt ;
        }

        if(grounded && !key_is_down(KEY_LEFT) && !key_is_down(KEY_RIGHT) && last == 0)
        {
            player.animation = PLAYER_ANIM_IDLE_LEFT;
            player.runAnimTime += dt ;
        }

        //Friction 
        if(!key_is_down(KEY_LEFT) &&
           !key_is_down(KEY_RIGHT))
        {
            if(!grounded)
            {
                player.speed.x = approach(player.speed.x, 0, runReduce * dt);
            }
            else
            {
                player.speed.x = approach(player.speed.x, 0, flyReduce * dt);
            }
        }

        //Gravity
        player.speed.y = approach(player.speed.y, fallSpeed, gravity * dt);



        // movimento
        IRect playerRect = get_player_rect();

        remainder.x += player.speed.x;
        int moveX = round(remainder.x);
        if (moveX != 0)
        {
            remainder.x -= moveX;
            int moveSign = sign(moveX);
            bool collisionHappened = false;

            auto movePlayerX = [&]
            {
                while (moveX)
                {
                    playerRect.pos.x += moveSign;

                    IVec2 playerGridPos = get_grid_pos(player.pos);
                    for (int x = playerGridPos.x - 1; x <= playerGridPos.x + 1; x++)
                    {
                        for (int y = playerGridPos.y - 3; y <= playerGridPos.y + 3; y++)
                        {
                            Tile* tile = get_tile(x, y);

                            if (!tile || !tile->isVisible)
                            {
                                continue;
                            }

                            IRect tileRect = get_tile_rect(x, y);
                            if (rect_collision(playerRect, tileRect))
                            {
                                handle_collision(player, tile);
                                player.speed.x = 0;
                                return;
                            }
                        }
                    }

                    player.pos.x += moveSign;
                    moveX -= moveSign;
                }
            };
            movePlayerX();
        }
    }

    {
        IRect playerRect = get_player_rect();

        remainder.y += player.speed.y;
        int moveY = round(remainder.y);
        if (moveY != 0)
        {
            remainder.y -= moveY;
            int moveSign = sign(moveY);
            bool collisionHappened = false;

            auto movePlayerY = [&]
            {
                while (moveY)
                {
                    playerRect.pos.y += moveSign;

                    IVec2 playerGridPos = get_grid_pos(player.pos);
                    for (int x = playerGridPos.x - 1; x <= playerGridPos.x + 1; x++)
                    {
                        for (int y = playerGridPos.y - 3; y <= playerGridPos.y + 3; y++)
                        {
                            Tile* tile = get_tile(x, y);

                            if (!tile || !tile->isVisible)
                            {
                                continue;
                            }

                            IRect tileRect = get_tile_rect(x, y);
                            if (rect_collision(playerRect, tileRect))
                            {
                                if (player.speed.y > 0.0f)
                                {
                                    grounded = true;
                                }

                                handle_collision(player, tile);
                                player.speed.y = 0;
                                return;
                            }
                        }
                    }

                    player.pos.y += moveSign;
                    moveY -= moveSign;
                }
            };
            movePlayerY();
        }
    }

    // tiles
    if (key_is_down(KEY_MOUSE_LEFT))
    {
        IVec2 worldPos = screen_to_world(input->mousePos);
        IVec2 mousePosWorld = input->mousePosWorld;
        Tile* tile = get_tile(worldPos);
        if (tile)
        {
            tile->isVisible = true;
        }
    }

    if (key_is_down(KEY_MOUSE_RIGHT))
    {
        IVec2 worldPos = screen_to_world(input->mousePos);
        IVec2 mousePosWorld = input->mousePosWorld;
        Tile* tile = get_tile(worldPos);
        if (tile)
        {
            tile->isVisible = false;
        }
    }
}

EXPORT_FN void update_game(GameState* gameStateIn, RenderData* renderDataIn, Input* inputIn, float dt)
{
    if (renderData != renderDataIn)
    {
        gameState = gameStateIn;
        renderData = renderDataIn;
        input = inputIn;
    }

    if (!gameState->initialized)
    {
        Player& player = gameState->player;
        player.animationSprites[PLAYER_ANIM_IDLE] = SPRITE_CHIBA;
        player.animationSprites[PLAYER_ANIM_RUN] = SPRITE_RUN;
        player.animationSprites[PLAYER_ANIM_PULO] = SPRITE_PULO;
        player.animationSprites[PLAYER_ANIM_IDLE_LEFT] = SPRITE_CHIBA_LEFT;
        player.animationSprites[PLAYER_ANIM_RUN_LEFT] = SPRITE_RUN_LEFT;
        player.animationSprites[PLAYER_ANIM_PULO_LEFT] = SPRITE_PULO_LEFT;

        renderData->gameCamera.dimensions = {WORLD_WIDTH, WORLD_HEIGHT};
        gameState->initialized = true;

        renderData->gameCamera.pos.x = 160;
        renderData->gameCamera.pos.y = -90;
    }

    {
        gameState->updateTimer += dt;
        while (gameState->updateTimer >= UPDATE_DELAY)
        {
            gameState->updateTimer -= UPDATE_DELAY;
            simulate();

            input->relMouse = input->mousePos - input->prevMousePos;
            input->prevMousePos = input->mousePos;

            {
                for (int keyCode = 0; keyCode < KEY_COUNT; keyCode++)
                {
                    input->keys[keyCode].justReleased = false;
                    input->keys[keyCode].justPressed = false;
                    input->keys[keyCode].halfTransitionCount = 0;
                }
            }
        }
    }

    float interpolatedDT = (float)(gameState->updateTimer / UPDATE_DELAY);

    // Player
    {
        Player& player = gameState->player;
        IVec2 playerPos = lerp(player.prevPos, player.pos, interpolatedDT);

        Sprite sprite = get_sprite(player.animationSprites[player.animation]);
        int animIdx = animate(&player.runAnimTime, sprite.frameCount, 0.6f);
        draw_sprite(player.animationSprites[player.animation], playerPos,
                    {
                        .animIdx = animIdx,
                        .render = player.render
                    });
    }

    // Draw Tiles
    // {
    //     for (int y = 0; y < WORLD_GRID.y; y++)
    //     {
    //         for (int x = 0; x < WORLD_GRID.x; x++)
    //         {
    //             Tile* tile = get_tile(x, y);

    //             if (!tile->isVisible)
    //             {
    //                 continue;
    //             }

    //             Vec2 tilePos = {x * (float)TILESIZE + (float)TILESIZE / 2.0f, y * (float)TILESIZE + (float)TILESIZE / 2.0f};
    //             draw_quad(tilePos, {8, 8});
    //         }
    //     }
    // }

    // int platformWidth = 10; // número de tiles na largura da plataforma
    // int platformY = WORLD_GRID.y / 2; // posição Y central
    // int platformXStart = (WORLD_GRID.x - platformWidth) / 2; // posição X centralizada

    // for (int x = platformXStart; x < platformXStart + platformWidth; x++)
    // {
    //     Tile* tile = &gameState->worldGrid[x][platformY];
    //     tile->isVisible = true;
    //     tile->isDangerous = false;
    // }



    //####################################################################
    //####                  Nivel gerado pelo chat gpt                ####
    //####################################################################    

    
    for (int x = 0; x < WORLD_GRID.x; x++)
    {
        Tile* tile = &gameState->worldGrid[x][WORLD_GRID.y - 1]; // Linha de baixo
        tile->isVisible = true; // Marca como visível
        tile->isDangerous = true; // Marca como perigoso

        Vec2 spikePos = {x * (float)TILESIZE + (float)TILESIZE / 2.0f, (WORLD_GRID.y - 1) * (float)TILESIZE + (float)TILESIZE / 2.0f};
        
        // Chama a função para desenhar espinhos
        draw_spike(spikePos, {8, 8});
    }

    // Cria plataformas escaláveis de 1 tile, indo da esquerda para a direita
    int platformYStart = WORLD_GRID.y - 5; // Altura inicial da primeira plataforma
    int step = 2; // Quantidade de linhas entre cada plataforma (altura da escalada)

    for (int i = 0; i < 5; i++) // Quantidade de plataformas
    {
        int platformX = i * 4; // Posição horizontal de cada plataforma (se movendo da esquerda para a direita)
        int platformY = platformYStart - (i * step); // Posição vertical, subindo a cada plataforma

        // Marca o tile como visível e não perigoso
        Tile* tile = &gameState->worldGrid[platformX][platformY];
        tile->isVisible = true; // Marca como visível
        tile->isDangerous = false; // Plataforma segura

        // Desenha a plataforma
        Vec2 tilePos = {platformX * (float)TILESIZE + (float)TILESIZE / 2.0f, platformY * (float)TILESIZE + (float)TILESIZE / 2.0f};
        draw_quad(tilePos, {8, 8}); // Pode ajustar o atlasOffset se houver um sprite específico para as plataformas
    }

}


