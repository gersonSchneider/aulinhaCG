#pragma once
#include "engine_lib.h"

//constants
//structs
enum SpriteID
{
    SPRITE_CHIBA,
    SPRITE_RUN,
    SPRITE_PULO,
    SPRITE_TILE,
    SPRITE_SPIKE,
    SPRITE_CHIBA_LEFT,
    SPRITE_RUN_LEFT,
    SPRITE_PULO_LEFT,
    SPRITE_FAR,
    SPRITE_NEAR,
    SPRITE_COUNT
};

struct Sprite
{
    IVec2 atlasOffset;
    IVec2 spriteSize;
    int frameCount;
};
//funções
Sprite get_sprite(SpriteID spriteID)
{
    Sprite sprite = {};
    sprite.frameCount = 1;

    switch(spriteID)
    {
        case SPRITE_CHIBA:
        {
            sprite.atlasOffset = {0, 0};
            sprite.spriteSize = {23, 36};
            sprite.frameCount = 9;
            break;
        }

        case SPRITE_RUN:
        {
            sprite.atlasOffset = {0, 38};
            sprite.spriteSize = {29, 37};
            sprite.frameCount = 5;
            break;
        }

        case SPRITE_PULO:
        {
            sprite.atlasOffset = {/*29*/0, 78};
            sprite.spriteSize = {27, 38};
            sprite.frameCount = 2;
            break;
        }

        case SPRITE_CHIBA_LEFT:
        {
            sprite.atlasOffset = {0, 267};
            sprite.spriteSize = {23, 36};
            sprite.frameCount = 9;
            break;
        }

        case SPRITE_RUN_LEFT:
        {
            sprite.atlasOffset = {0, 228};
            sprite.spriteSize = {29, 37};
            sprite.frameCount = 5;
            break;
        }

        case SPRITE_PULO_LEFT:
        {
            sprite.atlasOffset = {/*29*/0, 305};
            sprite.spriteSize = {27, 38};
            sprite.frameCount = 2;
            break;
        }

        case SPRITE_TILE:
        {
            sprite.atlasOffset = {6, 204};
            sprite.spriteSize = {16, 16};
            break;
        }

        case SPRITE_SPIKE:
        {
            sprite.atlasOffset = {0, 164};
            sprite.spriteSize = {18, 11};
            break;
        }

        case SPRITE_FAR:
        {
            sprite.atlasOffset = {186, 78};
            sprite.spriteSize = {58, 23};
            break;
        }

        case SPRITE_NEAR:
        {
            sprite.atlasOffset = {187, 107};
            sprite.spriteSize = {89, 28};
            break;
        }
    }

    return sprite;
}