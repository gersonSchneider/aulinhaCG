#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <array>
#include <cassert>
#include <math.h>

// Defines
#ifdef _WIN32
#define DEBUG_BREAK() __debugbreak()
#define EXPORT_FN __declspec(dllexport)
#endif
#define b8 char
#define BIT(x) 1 << (x)
#define KB(x) ((unsigned long long)1024* x)
#define MB(x) ((unsigned long long)1024* KB(x))
#define GB(x) ((unsigned long long)1024* MB(x))
// Log
enum TextColor
{
    TEXT_COLOR_PRETO,
    TEXT_COLOR_VERMELHO,
    TEXT_COLOR_VERDE,
    TEXT_COLOR_AMARELO,
    TEXT_COLOR_AZUL,
    TEXT_COLOR_ROSA,
    TEXT_COLOR_CIANO,
    TEXT_COLOR_BRANCO,
    TEXT_COLOR_CINZA,
    TEXT_COLOR_VERMELHO_C,
    TEXT_COLOR_VERDE_C,
    TEXT_COLOR_AMARELO_C,
    TEXT_COLOR_AZUL_C,
    TEXT_COLOR_ROSA_C,
    TEXT_COLOR_CIANO_C,
    TEXT_COLOR_BRANCO_C,
    TEXT_COLOR_COUNT
};

template <typename ...Args>
void _log(char* prefixo, char* msg, TextColor corTexto, Args ...args)
{
    static char* TextColorTable[TEXT_COLOR_COUNT] =
    {
        // ID          Cores
        "\x1b[30m", // preto
        "\x1b[31m", // vermelho
        "\x1b[32m", // verde
        "\x1b[33m", // amarelo
        "\x1b[34m", // azul
        "\x1b[35m", // rosa
        "\x1b[36m", // ciano
        "\x1b[37m", // branco
        "\x1b[90m", // cinza
        "\x1b[91m", // vermelhão
        "\x1b[92m", // verdão
        "\x1b[93m", // amarelão
        "\x1b[94m", // azulão
        "\x1b[96m", // rosão
        "\x1b[95m", // cianão (?)
        "\x1b[97m", // brancão
    };
    
    char formatBuffer[8192] = {};
    sprintf(formatBuffer, "%s %s %s \033[0m", TextColorTable[corTexto], prefixo, msg);

    char textBuffer[8192] = {};
    sprintf(textBuffer, formatBuffer, args...);

    puts(textBuffer);
}

#define SM_TRACE(msg, ...) _log("TRACE: ", msg, TEXT_COLOR_VERDE, ##__VA_ARGS__);
#define SM_WARN(msg, ...) _log("WARN: ", msg, TEXT_COLOR_AMARELO, ##__VA_ARGS__);
#define SM_ERROR(msg, ...) _log("ERROR: ", msg, TEXT_COLOR_VERMELHO, ##__VA_ARGS__);

#define SM_ASSERT(x, msg, ...)                            \
{                                                         \
    if(!(x))                                              \
    {                                                     \
        SM_ERROR(msg, ##__VA_ARGS__);                     \
        DEBUG_BREAK();                                    \
        SM_ERROR("Assertion Hit!");                       \
    }                                                     \
}


// Bump Pointer
struct BumpAllocator
{
    size_t capacidade;
    size_t utilizado;
    char* memoria;
};

BumpAllocator allocator(size_t tamanho)
{
    BumpAllocator ba = {};

    ba.memoria = (char*)malloc(tamanho);

    if(ba.memoria)
    {
        ba.capacidade = tamanho;
        memset(ba.memoria, 0, tamanho); // setar memoria para 0
    }
    else
    {
        SM_ASSERT(false, "Falha ao alocar memória");
    }

    return ba;
}

char* bump_alloc(BumpAllocator* bumpAllocator, size_t tamanho)
{
    char* resultado = nullptr;

    size_t tamanhoAlinhado = (tamanho + 7) & ~7; // pra ter certeza que primeiros 4 bits sejam 0
    if(bumpAllocator->utilizado + tamanhoAlinhado <= bumpAllocator->capacidade)
    {
        resultado = bumpAllocator->memoria + bumpAllocator->utilizado;
        bumpAllocator->utilizado += tamanhoAlinhado;
    }
    else
    {
        SM_ASSERT(false, "Bump Allocator está cheio");
    }

    return resultado;
}

// Inputs e Outputs
long long tempoCorrido(const char* jogo)
{
    struct stat jogo_stat = {};
    stat(jogo, &jogo_stat);
    return jogo_stat.st_mtime;
}

bool jogo_existe(char* dir)
{
    SM_ASSERT(dir, "Não existe o diretório do arquivo");

    FILE* jogo = fopen(dir, "rb");
    if (!jogo)
    {
        return false;
    }
    fclose(jogo);

    return true;
}

long tamanho_jogo(const char* dir)
{
    SM_ASSERT(dir, "Não existe o diretório do arquivo");

    long tamanhoJogo = 0;
    FILE* jogo = fopen(dir, "rb");
    if (!jogo)
    {
        SM_ERROR("Falha ao abrir arquivo: %s", dir);
        return 0;
    }

    fseek(jogo, 0, SEEK_END);
    tamanhoJogo = ftell(jogo);
    fseek(jogo, 0, SEEK_SET);
    fclose(jogo);

    return tamanhoJogo;
}

// tudo aqui deixa controlar onde algo é alocado
char* read_file(const char* dir, int* tamanhoJogo, char* buffer)
{
    SM_ASSERT(dir, "Diretóro não fornecido");
    SM_ASSERT(tamanhoJogo, "Tamanho não fornecido");
    SM_ASSERT(buffer, "Buffer não fornecido");

    *tamanhoJogo = 0;
    FILE* jogo = fopen(dir, "rb");
    if (!jogo)
    {
        SM_ERROR("Falha ao abrir arquivo %s", dir);
        return nullptr;
    }
    
    fseek(jogo, 0, SEEK_END);
    *tamanhoJogo = ftell(jogo);
    fseek(jogo, 0, SEEK_SET);

    memset(buffer, 0, *tamanhoJogo + 1);
    fread(buffer, sizeof(char), *tamanhoJogo, jogo);

    fclose(jogo);

    return buffer;
}

char* read_file(const char* dir, int* tamanhoJogo, BumpAllocator* bumpAllocator)
{
    char* jogo = nullptr;
    long tamanhoJogo2 = tamanho_jogo(dir);

    if (tamanhoJogo2)
    {
        char* buffer = bump_alloc(bumpAllocator, tamanhoJogo2 + 1);

        if (!buffer)
        {
            SM_ERROR("Falha ao alocar memória para cópia");
            return nullptr;
        }

        jogo = read_file(dir, tamanhoJogo, buffer);
    }

    return jogo;
}

void write_file(const char* dir, char* buffer, int tamanhoJogo)
{
    SM_ASSERT(dir, "Diretóro não fornecido");
    SM_ASSERT(buffer, "Buffer não fornecido");
    auto jogo = fopen(dir, "rb");
    if (!jogo)
    {
        SM_ERROR("Falha ao abrir arquivo %s", dir);
        return;
    }

    fwrite(buffer, sizeof(char), tamanhoJogo, jogo);
    fclose(jogo);
}

bool copy_file(const char* nome, char* outputName, char* buffer)
{
    int tamanhoJogo = 0;
    char* data = read_file(nome, &tamanhoJogo, buffer);

    if (!data)
    {
        return false;
    }

    auto outputFile = fopen(outputName, "wb");
    if (!outputFile)
    {
        SM_ERROR("Falha ao abrir arquivo %s", outputName);
        return false;
    }

    fwrite(data, sizeof(char), tamanhoJogo, outputFile);
    fclose(outputFile);
    return true;
}

bool copy_file(const char* nome, char* outputName, BumpAllocator* bumpAllocator)
{
    char* jogo = 0;
    long tamanhoJogo2 = tamanho_jogo(nome);

    if (tamanhoJogo2)
    {
        char* buffer = bump_alloc(bumpAllocator, tamanhoJogo2 + 1);

        if (!buffer)
        {
            SM_ERROR("Falha ao alocar memória para cópia");
            return false;
        }

        return copy_file(nome, outputName, buffer);
    }

    return false;
};


//matematiquinhas
// long long max(long long a, long long b)
// {
//     if(a > b)
//     {
//         return a;
//     }

//     return b;
// }

int sign(int x)
{
  return (x >= 0)? 1 : -1;
}

float sign(float x)
{
  return (x >= 0.0f)? 1.0f : -1.0f;
}

int min(int a, int b)
{
  return (a < b)? a : b;
}

int max(int a, int b)
{
  return (a > b)? a : b;
}

long long max(long long a, long long b)
{
  if(a > b)
  {
    return a;
  }

  return b;
}

float max(float a, float b)
{
  if(a > b)
  {
    return a;
  }

  return b;
}

float min(float a, float b)
{
  if(a < b)
  {
    return a;
  }

  return b;
}

float approach(float current, float target, float increase)
{
  if(current < target)
  {
    return min(current + increase, target);
  }
  return max(current - increase, target);
}

float lerp(float a, float b, float t)
{
  return a + (b - a) * t;
}

struct Vec2
{
    float x;
    float y;

    Vec2 operator/(float scalar)
    {
        return {x / scalar, y / scalar};
    }

    Vec2 operator-(Vec2 other)
    {
        return {x - other.x, y - other.y};
    }
};


struct IVec2
{
    int x;
    int y;

    IVec2 operator-(IVec2 other) const
    {
        return {x - other.x, y - other.y};
    }
};

struct Vec4
{
    union
    {
        float values[4];
        struct
        {
            float x;
            float y;
            float z;
            float w;
        };

        struct
        {
            float r;
            float g;
            float b;
            float a;
        };
        
    };

    float& operator[](int idx)
    {
        return values[idx];
    };

};


struct Mat4
{
    union
    {
        Vec4 values[4];
        struct
        {
            float ax;
            float bx;
            float cx;
            float dx;

            float ay;
            float by;
            float cy;
            float dy;

            float az;
            float bz;
            float cz;
            float dz;

            float aw;
            float bw;
            float cw;
            float dw;
        };
    };

    Vec4& operator[](int col)
    {
        return values[col];
    }

};



Mat4 orthographic_projection(float left, float right, float top, float bottom)
{
    Mat4 resultado = {};
    resultado.aw = -(right + left) / (right - left);
    resultado.bw = (top + bottom) / (top - bottom);
    resultado.cw = 0.0f;
    resultado[0][0] = 2.0f / (right - left);
    resultado[1][1] = 2.0f / (top - bottom);
    resultado[2][2] = 1.0f / (1.0f - 0.0f);
    resultado[3][3] = 1.0f;

    return resultado;
}

Vec2 vec_2(IVec2 v)
{
  return Vec2{(float)v.x, (float)v.y};
}

Vec2 lerp(Vec2 a, Vec2 b, float t)
{
    Vec2 resultado;
    resultado.x = lerp(a.x, b.x, t);
    resultado.y = lerp(a.y, b.y, t);
    return resultado;
}

IVec2 lerp(IVec2 a, IVec2 b, float t)
{
    IVec2 resultado;
    resultado.x = (int)floorf(lerp((float)a.x,(float)b.x, t));
    resultado.y = (int)floorf(lerp((float)a.y,(float)b.y, t));
    return resultado;
}

struct Rect
{
    Vec2 pos;
    Vec2 size;
};

struct IRect
{
    IVec2 pos;
    IVec2 size;
};

bool point_in_rect(Vec2 point, Rect rect)
{
    return (point.x >= rect.pos.x &&
            point.x <= rect.pos.x + rect.size.x &&
            point.y >= rect.pos.y &&
            point.y <= rect.pos.y + rect.size.y);
}

bool rect_collision(IRect a, IRect b)
{
    return a.pos.x < b.pos.x + b.size.x &&
           a.pos.x + a.size.x > b.pos.x &&
           a.pos.y < b.pos.y + b.size.y &&
           a.pos.y + a.size.y > b.pos.y;
}

//oi