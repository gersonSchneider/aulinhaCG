#include "engine_lib.h"
#include "input.h"
#include "jogo.h"

#define APIENTRY
#define GL_GLEXT_PROTOTYPES
#include "glcorearb.h"


#include "platform.h"
#ifdef _WIN32
#include "win32_platform.cpp"
#endif

#include "gl_renderer.cpp"

//static KeyCodeID KeyCodeLookupTable[KEY_COUNT];

//dll
typedef decltype(update_game) update_game_type;
static update_game_type* update_game_ptr;

char* gameDLLName = "jogo.dll";
char* gameLoadDLLName = "game_load.dll";

#include <chrono>
double get_delta_time();
void reload_game_dll(BumpAllocator* reservaMem);




int main()
{
    get_delta_time();

    BumpAllocator reservaMem = allocator(MB(50));
    BumpAllocator persistentStorage = allocator(MB(50));

    input = (Input*)bump_alloc(&persistentStorage, sizeof(Input));
        if(!input)
    {
        SM_ERROR("Falha ao alocar input");
        return -1;
    }

    renderData = (RenderData*)bump_alloc(&persistentStorage, sizeof(RenderData));
        if(!renderData)
    {
        SM_ERROR("Falha ao alocar RenderData");
        return -1;
    }

    gameState = (GameState*)bump_alloc(&persistentStorage, sizeof(GameState));
    if(!gameState)
    {
        SM_ERROR("Falha ao alocar gamestate");
        return -1;
    }

    platform_fill_keycode_lookup_table();
    criar_janela(1280, 720, "UwU da gaem");
    platform_set_vsync(true);
    // input->screenSize.x = 1200;
    // input->screenSize.y = 720;

    gl_init(&reservaMem);
    reload_game_dll(&reservaMem);

    while(running)
    {
        float dt = get_delta_time();

        reload_game_dll(&reservaMem);
        // Update
        atualizar_janela();
        update_game(gameState, renderData, input, dt);
        gl_render(&reservaMem);
        platform_swap_buffers();

        reservaMem.utilizado = 0;
    }


    return 0;
}

void update_game(GameState* gameStateIn, RenderData* renderDataIn, Input* inputIn, float dt)
{
    update_game_ptr(gameStateIn, renderDataIn, inputIn, dt);
}

double get_delta_time()
{
    static auto lastTime = std::chrono::steady_clock::now();
    auto currentTime = std::chrono::steady_clock::now();

    double delta = std::chrono::duration<double>(currentTime - lastTime).count();
    lastTime = currentTime;
    
    return delta;
}

void reload_game_dll(BumpAllocator* reservaMem)
{
    static void* gameDLL;
    static long long lastEditTimestampGameDLL;

    long long currentTimestampGameDLL = tempoCorrido("jogo.dll");
    if(currentTimestampGameDLL > lastEditTimestampGameDLL)
    {
        if(gameDLL)
        {
            bool freeResult = platform_free_dynamic_library(gameDLL);
            SM_ASSERT(freeResult, "Falha ao soltar game.dll");
            gameDLL = nullptr;
            SM_TRACE("dll solta %s", gameDLLName);
        }

        while(!copy_file("jogo.dll", "game_load.dll", reservaMem))
        {
            Sleep(10);
        }
        SM_TRACE("Copiado %s", gameDLLName);

        gameDLL = platform_load_dynamic_library("game_load.dll");
        SM_ASSERT(gameDLL, "Falha ao carregar dll");

        update_game_ptr = (update_game_type*)platform_load_dynamic_function(gameDLL, "update_game");
        SM_ASSERT(update_game_ptr, "Falha ao carregar função update_game");
        lastEditTimestampGameDLL = currentTimestampGameDLL;
    }
}

