#pragma once
// ----------- Plataforma Global -----------
static bool running = true;

// ----------- Funções -----------
bool criar_janela(int width, int height, char* titulo);
void atualizar_janela();
void* platform_load_gl_function(char* nome);
void platform_swap_buffers();
void platform_set_vsync(bool vSync);
void* platform_load_dynamic_library(char* dll);
void* platform_load_dynamic_function(void* dll, char* nome);
bool platform_free_dynamic_library(void* dll);
void platform_fill_keycode_lookup_table();