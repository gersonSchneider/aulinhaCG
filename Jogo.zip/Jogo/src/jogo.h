#pragma once
#include "engine_lib.h"
#include "render_interface.h"
#include "input.h"

//globals
constexpr int UPDATES_PER_SECOND = 60;
constexpr double UPDATE_DELAY = 1.0 / UPDATES_PER_SECOND;
constexpr int WORLD_WIDTH = 320;
constexpr int WORLD_HEIGHT = 180;
constexpr int TILESIZE = 8;
constexpr IVec2 WORLD_GRID = {WORLD_WIDTH / TILESIZE, WORLD_HEIGHT / TILESIZE};

//structs
enum TileType
{
    TILE_NORMAL,
    TILE_DANGEROUS
};


struct Tile
{
    bool isVisible;
    bool isDangerous;
};

enum animState
{
    PLAYER_ANIM_IDLE,
    PLAYER_ANIM_RUN,
    PLAYER_ANIM_PULO,
    PLAYER_ANIM_IDLE_LEFT,
    PLAYER_ANIM_RUN_LEFT,
    PLAYER_ANIM_PULO_LEFT,

    PLAYER_ANIM_COUNT
};

struct Player
{
    IVec2 pos;
    IVec2 prevPos;
    Vec2 speed;
    int render;
    float runAnimTime;
    animState animation;
    SpriteID animationSprites[PLAYER_ANIM_COUNT];
};

struct GameState
{
    float updateTimer;
    bool initialized = false;
    Player player;
    Tile worldGrid[WORLD_GRID.x][WORLD_GRID.y];
    int lastPressed = 1;
};

static GameState* gameState;

//func
extern "C" 
{
    EXPORT_FN void update_game(GameState* gameStateIn, RenderData* renderDataIn, Input* inputIn, float dt);
}