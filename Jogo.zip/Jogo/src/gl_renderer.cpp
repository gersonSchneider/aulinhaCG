#include "gl_renderer.h"
#include <glcorearb.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "render_interface.h"
#include "input.h"
#include <GL/gl.h>

const char* TEXTURE_PATH = "assets/texturas/atlas.png";

// Estruturas
struct GLContext
{
    GLuint programID;
    GLuint textureID;
    GLuint transformSBOID;
    GLuint screenSizeID;
    GLuint orthoProjectionID;

    long long textureTimestamp;
    long long shaderTimeStamp;
};

// Globals
static GLContext glContext;

// Funções
static void APIENTRY gl_debug_callback(GLenum source, GLenum type, GLuint id, GLenum severity,
                                        GLsizei length, const GLchar* msg, const void* user)
{
    if(severity == GL_DEBUG_SEVERITY_LOW ||
       severity == GL_DEBUG_SEVERITY_MEDIUM ||
       severity == GL_DEBUG_SEVERITY_HIGH)
       {
        SM_ASSERT(0, "Erro no OpenGL: %s", msg);
       }
    else
    {
        SM_TRACE((char*)msg);
    }
}

GLuint gl_create_shader(int shaderType, char* shaderPath, BumpAllocator* reservaMem)
{
    int fileSize = 0;
    char* vertShader = read_file(shaderPath, &fileSize, reservaMem);
    if(!vertShader)
    {
        SM_ASSERT(false, "Falha ao carregar shader: %s", shaderPath);
        return 0;
    }

    GLuint shaderID = glCreateShader(shaderType);
    glShaderSource(shaderID, 1, &vertShader, 0);
    glCompileShader(shaderID);

    {
        int sucesso;
        char shaderLog[2048] = {};
        
        glGetShaderiv(shaderID, GL_COMPILE_STATUS, &sucesso);
        if(!sucesso)
        {
            glGetShaderInfoLog(shaderID, 2048, 0, shaderLog);
            SM_ASSERT(false, "Falha ao compilar %s shader, erro %s", shaderPath, shaderLog);
            return 0;
        }
    }

    return shaderID;
}



bool gl_init(BumpAllocator* reservaMem)
{
    load_gl_functions();

    glDebugMessageCallback(&gl_debug_callback, nullptr);
    glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
    glEnable(GL_DEBUG_OUTPUT);

    // GLuint vertShaderID = glCreateShader(GL_VERTEX_SHADER);
    // GLuint fragShaderID = glCreateShader(GL_FRAGMENT_SHADER);

    // int tamanhoJogo;
    // char* vertShader = read_file("assets/shaders/quad.vert", &tamanhoJogo, reservaMem);
    // char* fragShader = read_file("assets/shaders/quad.frag", &tamanhoJogo, reservaMem);

    // if(!vertShader || !fragShader)
    // {
    //     SM_ASSERT(false, "Falha ao carregar shaders");
    //     return false;
    // }

    // glShaderSource(vertShaderID, 1 , &vertShader, 0);
    // glShaderSource(fragShaderID, 1 , &fragShader, 0);

    // glCompileShader(vertShaderID);
    // glCompileShader(fragShaderID);

    // {
    //     int sucesso;
    //     char shaderLog[2048] = {};

    //     glGetShaderiv(vertShaderID, GL_COMPILE_STATUS, &sucesso);
    //     if(!sucesso)
    //     {
    //         glGetShaderInfoLog(vertShaderID, 2048, 0, shaderLog);
    //         SM_ASSERT(false, "Falha ao compilar vertex shaders %s", shaderLog);
    //     }
    // }

    // {
    //     int sucesso;
    //     char shaderLog[2048] = {};

    //     glGetShaderiv(fragShaderID, GL_COMPILE_STATUS, &sucesso);
    //     if(!sucesso)
    //     {
    //         glGetShaderInfoLog(fragShaderID, 2048, 0, shaderLog);
    //         SM_ASSERT(false, "Falha ao compilar vertex shaders %s", shaderLog);
    //     }
    // }

    GLuint vertShaderID = gl_create_shader(GL_VERTEX_SHADER,
                                            "assets/shaders/quad.vert", reservaMem);

    GLuint fragShaderID = gl_create_shader(GL_FRAGMENT_SHADER,
                                            "assets/shaders/quad.frag", reservaMem);

    if(!vertShaderID || !fragShaderID)
    {
        SM_ASSERT(false, "Falha ao criar shaders");
        return false;
    }

    long long timestampVert = tempoCorrido("assets/shaders/quad.vert");
    long long timestampFrag = tempoCorrido("assets/shaders/quad.frag");
    glContext.shaderTimeStamp = max(timestampVert, timestampFrag);

    glContext.programID = glCreateProgram();
    glAttachShader(glContext.programID, vertShaderID);
    glAttachShader(glContext.programID, fragShaderID);
    glLinkProgram(glContext.programID);

    glDetachShader(glContext.programID, vertShaderID);
    glDetachShader(glContext.programID, fragShaderID);
    glDeleteShader(vertShaderID);
    glDeleteShader(fragShaderID);

    GLuint VAO;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    // carregar texturas
    {
        int width, height, channels;
        char* data = (char*)stbi_load(TEXTURE_PATH, &width, &height, &channels, 4);
        if(!data)
        {
        SM_ASSERT(false, "Falha ao carregar texturas");
        return false;
        }
        
        glGenTextures(1, &glContext.textureID);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, glContext.textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB8_ALPHA8, width, height,
                     0, GL_RGBA, GL_UNSIGNED_BYTE, data);

        glContext.textureTimestamp = tempoCorrido(TEXTURE_PATH);
        
        stbi_image_free(data);
    }


    //storage buffer
    {
        glGenBuffers(1, &glContext.transformSBOID);
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, 0, glContext.transformSBOID);
        glBufferData(GL_SHADER_STORAGE_BUFFER, sizeof(Transform) * MAX_TRANSFORMS,
                     renderData->transforms, GL_DYNAMIC_DRAW);
    }

    //uniform
    {
        glContext.screenSizeID = glGetUniformLocation(glContext.programID, "screenSize");
        glContext.orthoProjectionID = glGetUniformLocation(glContext.programID, "orthoProjection");

    }

    glEnable(GL_FRAMEBUFFER_SRGB);
    glDisable(0x809D); //multisampling

    //depth test
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_GREATER);

    //Usar programa
    glUseProgram(glContext.programID);

    return true;
    
}

void gl_render(BumpAllocator* reservaMem)
{
    //texturas

    {
        long long currentTimestamp = tempoCorrido(TEXTURE_PATH);

        if(currentTimestamp > glContext.textureTimestamp)
        {
            glActiveTexture(GL_TEXTURE0);
            int width, height, nChannels;
            char* data = (char*)stbi_load(TEXTURE_PATH, &width, &height, &nChannels, 4);
            if(data)
            {
                glContext.textureTimestamp = currentTimestamp;
                glTexImage2D(GL_TEXTURE_2D, 0 , GL_SRGB8_ALPHA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
                stbi_image_free(data);
            }
        }
    }

    //shaders

    {
        long long timestampVert = tempoCorrido("asset/shaders/quad.vert");
        long long timestampFrag = tempoCorrido("asset/shaders/quad.Frag");

        if(timestampVert > glContext.shaderTimeStamp || timestampFrag > glContext.shaderTimeStamp)
        {
            GLuint vertShaderID = gl_create_shader(GL_VERTEX_SHADER, "assets/shaders/quad.vert", reservaMem);
            GLuint fragShaderID = gl_create_shader(GL_VERTEX_SHADER, "assets/shaders/quad.frag", reservaMem);

            if(!vertShaderID || !fragShaderID)
            {
                SM_ASSERT(false, "Falha ao criar shaders");
                return;
            }
            glAttachShader(glContext.programID, vertShaderID);
            glAttachShader(glContext.programID, fragShaderID);
            glLinkProgram(glContext.programID);

            glDetachShader(glContext.programID, vertShaderID);
            glDetachShader(glContext.programID, fragShaderID);
            glDeleteShader(vertShaderID);
            glDeleteShader(fragShaderID);

            glContext.shaderTimeStamp = max(timestampVert, timestampFrag);
        }
    }


    glClearColor(51.0f / 255.0f, 51.0f / 255.0f, 180.0f / 255.0f, 1.0f);
    glClearDepth(0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glViewport(0, 0, input->screenSize.x, input->screenSize.y);

    Vec2 screenSize = {(float)input->screenSize.x, (float)input->screenSize.y};
    glUniform2fv(glContext.screenSizeID, 1, &screenSize.x);

    OrthographicCamera2D camera = renderData->gameCamera;
    Mat4 orthoProjection = orthographic_projection(camera.pos.x - camera.dimensions.x / 2.0f,
                                                   camera.pos.x + camera.dimensions.x / 2.0f,
                                                   camera.pos.y - camera.dimensions.y / 2.0f,
                                                   camera.pos.y + camera.dimensions.y / 2.0f);
    glUniformMatrix4fv(glContext.orthoProjectionID, 1 , GL_FALSE, &orthoProjection.ax);

    //texturas opacas
    {
        glBufferSubData(GL_SHADER_STORAGE_BUFFER, 0, sizeof(Transform) * renderData->transformCount,
                        renderData->transforms);

        glDrawArraysInstanced(GL_TRIANGLES, 0, 6, renderData->transformCount);

        // reseta pro proximo quadro
        renderData->transformCount = 0;
    }

    //glDrawArrays(GL_TRIANGLES, 0, 6);
}