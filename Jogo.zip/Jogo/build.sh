#!/bin/bash

timestamp=$(date +%s)

libs="-luser32 -lopengl32 -lgdi32"
warnings="-Wno-writable-strings -Wno-format-security -Wno-deprecated-declarations -Wno-switch"
includes="-Ithird_party -Ithird_party/Include"

clang++ $includes -g src/main.cpp -oengine.exe $libs $warnings

rm -f jogo_* #pra nao afogar lotar a pasta de dll
clang++ -g "src/jogo.cpp" -shared -o jogo_$timestamp.dll $warnings
mv jogo_$timestamp.dll jogo.dll